create DATABASE bzpowerIntelligentLock;
use bzpowerIntelligentLock;
